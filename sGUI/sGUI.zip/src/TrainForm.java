import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

public class TrainForm extends JFrame {
    private JTextField tfTrainID;
    private JTextField tfTrainName;
    private JTextField tfTrainNo;
    private JTextField tfNoofS;
    private JButton saveTrainToOurButton;
    private JButton clearButton;
    private JPanel TrainForm;

    public TrainForm(Connection connection, int AdminID)
    {
        setContentPane(TrainForm);
        setTitle("Add a Train to our System");
        setSize(450,300);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        saveTrainToOurButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Train MyTain= new Train(connection);
                int TrainID=Integer.parseInt(tfTrainID.getText());
                String TrainName=tfTrainName.getText();
                int TrainNumber=Integer.parseInt(tfTrainNo.getText());
                int Seats=Integer.parseInt(tfNoofS.getText());
                MyTain.AddTrain(TrainID,TrainName,TrainNumber,Seats,AdminID);
            }
        });
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                tfTrainName.setText("");
                tfTrainID.setText("");
                tfNoofS.setText("");
                tfTrainNo.setText("");
            }
        });
    }
}
